package com.myapplication.utility

object Constants {

   val  APIKEY:String = "765206b1932cfc4dc442900c4459b0c3"

}